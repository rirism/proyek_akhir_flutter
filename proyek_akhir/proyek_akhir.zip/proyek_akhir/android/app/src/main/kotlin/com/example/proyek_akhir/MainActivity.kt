package com.example.proyek_akhir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
